## Mongo Atlas

### mongodb on cloud. Database as a service. uses amazon ec2 for actual database deployment.helpful for collaboration.

*   Signup on mongodb.com
*   add users to cluster
*   whitelist IP's
*   connect to mongodb compass using clipboard
*   application connect


## MySQL database on Google cloud platform

### mysql database deployed on google cloud. creates an instance and database.

*   Add IP's to authorization list
*   generate client certificates for team.
*   connection in workbench using ssl to view data
*   application connect
